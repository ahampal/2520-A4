Name:
Amit Hampal

Student #:
0964514

Description:
This program takes a conversational text file as input contains rules. These
rules can be added, removed, and modified. These rules also form the bases for
a Question and answer based program where the highest rule for a question is
displayed as an answer to a question

Compilation:
execute 'make API' to create HashTableAPI library
execute 'make' to compile main.c
execute 'make test' to create testMain
execute './main fileName.txt' from bin  to run main with txt file in same folder
execute './main ../directorypath/fileName.txt' from bin to run main with txt file
in a different directory

Assumptions and limitations:
No assumptions made. Limitations are that the program see rules as 
case-insensitive, and that the sentences outputted are a single line of text

I have included a sample conversation text file

Personalization:
No personalizations made
